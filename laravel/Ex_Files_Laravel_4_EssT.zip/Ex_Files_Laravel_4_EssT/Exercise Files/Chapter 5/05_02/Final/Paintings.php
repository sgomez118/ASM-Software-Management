<?php

class Paintings extends Eloquent
{

}
