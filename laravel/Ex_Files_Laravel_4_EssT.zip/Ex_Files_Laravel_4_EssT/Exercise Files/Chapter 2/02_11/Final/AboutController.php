<?php

class AboutController extends BaseController {

    public function showAbout()
    {
        return 'ABOUT content';
    }

}